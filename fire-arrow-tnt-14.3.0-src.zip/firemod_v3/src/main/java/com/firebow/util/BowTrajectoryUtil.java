package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public final class BowTrajectoryUtil {
    private BowTrajectoryUtil() {}

    public static BlockPos predictLanding(ClientPlayerEntity player, int useTimeLeft) {
        World world = player.getWorld();
        float pull = BowItem.getPullProgress(useTimeLeft);
        if (pull < 0.1f) return null;

        float speed    = pull * 3.0f;
        float yawRad   = (float) Math.toRadians(player.getYaw());
        float pitchRad = (float) Math.toRadians(player.getPitch());

        double vx = -Math.sin(yawRad) * Math.cos(pitchRad);
        double vy = -Math.sin(pitchRad);
        double vz =  Math.cos(yawRad) * Math.cos(pitchRad);

        double len = Math.sqrt(vx*vx + vy*vy + vz*vz);
        if (len == 0) return null;
        vx = vx / len * speed;
        vy = vy / len * speed;
        vz = vz / len * speed;

        Vec3d eye = player.getEyePos();
        double x = eye.x, y = eye.y, z = eye.z;

        for (int i = 0; i < 120; i++) {
            vy -= 0.05;
            vx *= 0.99; vy *= 0.99; vz *= 0.99;
            x += vx; y += vy; z += vz;

            BlockPos floor = new BlockPos(
                (int) Math.floor(x),
                (int) Math.floor(y) - 1,
                (int) Math.floor(z));

            if (!world.getBlockState(floor).isAir()) {
                BlockPos rail = floor.up();
                if (world.getBlockState(rail).isAir()) return rail;
                return null;
            }
        }
        return null;
    }

    public static boolean isHoldingBow(ClientPlayerEntity player) {
        return player.getMainHandStack().getItem() instanceof BowItem ||
               player.getOffHandStack().getItem() instanceof BowItem;
    }
}
